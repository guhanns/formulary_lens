import React, { useState, useMemo, useRef } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";
import sample from "./Gen Pharma Agreement.pdf";
import { Modal, ModalBody, ModalHeader } from "reactstrap";
import request from "../../../api/api";

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

const PdfViewerWithPopup = ({ file, filename }) => {
  const fileUrl = useMemo(() => file || sample, [file]);
  const containerRef = useRef();

  const [numPages, setNumPages] = useState(null);
  const [selectedText, setSelectedText] = useState("");
  const [popupPos, setPopupPos] = useState(null);
  const [showCommentBox, setShowCommentBox] = useState(false);
  const [comment, setComment] = useState("");
  const [highlights, setHighlights] = useState([]);
  const [isExplain, setIsExplain] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [extraction, setExtraction] = useState({});

  // ✅ Handle text selection & position
  const handleMouseUp = () => {
    const selection = window.getSelection();
    const text = selection.toString().trim();

    if (text && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      const containerRect = containerRef.current.getBoundingClientRect();
      const scrollY = containerRef.current.scrollTop;

      setSelectedText(text);
      setPopupPos({
        top: rect.top - containerRect.top + scrollY - 40,
        left: rect.left - containerRect.left + rect.width / 2,
        rect: {
          top: rect.top - containerRect.top + scrollY,
          left: rect.left - containerRect.left,
          width: rect.width,
          height: rect.height,
        },
      });

      setShowCommentBox(false);
    } else {
      // setSelectedText("");
      setPopupPos(null);
      setShowCommentBox(false);
    }
  };

  // ✅ Save comment & highlight text region
  const handleAddComment = () => {
    if (!comment.trim() || !selectedText) return;

    const newHighlight = {
      id: Date.now(),
      text: selectedText,
      rect: popupPos.rect,
      comment,
      color: "rgba(255, 255, 0, 0.5)", // yellow highlight
    };

    setHighlights((prev) => [...prev, newHighlight]);
    setSelectedText("");
    setComment("");
    setPopupPos(null);
    setShowCommentBox(false);
  };

  // ✅ Explain feature
  const handleExplainThis = async () => {
    setIsExplain(true);
    if (!selectedText.trim()) return;

    try {
      const res = await request({
        url: "/icontract/backend/clause_extraction",
        method: "GET",
        params: {
          query: selectedText,
          filename,
        },
      });

      if (res.success) {
        setIsLoading(false);
        setExtraction(res);
      }
    } catch (error) {
      console.error("Explain API error:", error);
    } finally {
      setSelectedText("");
      setPopupPos(null);
    }
  };

  const handleCloseExtraction = () => {
    setIsExplain(false);
    setExtraction({});
    setIsLoading(true);
  };

  return (
    <div
      ref={containerRef}
      onMouseUp={handleMouseUp}
      style={{
        position: "relative",
        width: "100%",
        height: "100vh",
        overflowY: "auto",
        background: "#f8f9fa",
        padding: "10px",
      }}
    >
      {/* PDF Document */}
      <Document file={fileUrl} onLoadSuccess={({ numPages }) => setNumPages(numPages)}>
        {Array.from(new Array(numPages), (_, index) => (
          <div
            key={index}
            style={{
              position: "relative",
              marginBottom: "20px",
              display: "flex",
              justifyContent: "center",
            }}
          >
            <Page pageNumber={index + 1} width={800} />
          </div>
        ))}
      </Document>

      {/* Render highlights */}
      {highlights.map((h) => (
        <div
          key={h.id}
          title={h.comment}
          style={{
            position: "absolute",
            top: h.rect.top,
            left: h.rect.left,
            width: h.rect.width,
            height: h.rect.height,
            backgroundColor: h.color,
            borderRadius: "3px",
            pointerEvents: "none",
            zIndex: 3,
          }}
        />
      ))}

      {/* Popup: Add Comment / Explain */}
      {selectedText && popupPos && !showCommentBox && (
        <div
          style={{
            position: "absolute",
            top: popupPos.top,
            left: popupPos.left,
            transform: "translate(-50%, -100%)",
            background: "white",
            border: "1px solid #ccc",
            borderRadius: "6px",
            boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
            padding: "6px",
            display: "flex",
            gap: "6px",
            zIndex: 10,
          }}
          onMouseDown={(e) => e.stopPropagation()}
        >
          <button
            onClick={() => setShowCommentBox(true)}
            style={{
              padding: "4px 8px",
              fontSize: "12px",
              background: "#007bff",
              color: "#fff",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            Add Comment
          </button>
          <button
            onClick={handleExplainThis}
            style={{
              padding: "4px 8px",
              fontSize: "12px",
              background: "#28a745",
              color: "#fff",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            Explain This
          </button>
        </div>
      )}

      {/* Comment Box */}
      {selectedText && showCommentBox && popupPos && (
        <div
          style={{
            position: "absolute",
            top: popupPos.top,
            left: popupPos.left,
            transform: "translate(-50%, -100%)",
            background: "white",
            border: "1px solid #ccc",
            borderRadius: "8px",
            boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
            zIndex: 10,
            padding: "10px",
            width: "220px",
          }}
          onMouseDown={(e) => e.stopPropagation()}
        >
          <div style={{ fontSize: "12px", fontWeight: "bold", marginBottom: "5px" }}>
            Add Comment
          </div>
          <textarea
            rows={2}
            value={comment}
            placeholder="Type your comment..."
            onClick={(e) => e.stopPropagation()}
            onChange={(e) => {
              e.stopPropagation();
              setComment(e.target.value)
            }}
            style={{
              width: "100%",
              fontSize: "12px",
              padding: "4px",
              border: "1px solid #ccc",
              borderRadius: "5px",
              resize: "none",
            }}
          />
          <div style={{ marginTop: "6px", textAlign: "right" }}>
            <button
              onClick={handleAddComment}
              style={{
                background: "#007bff",
                color: "#fff",
                border: "none",
                borderRadius: "5px",
                padding: "4px 8px",
                cursor: "pointer",
                fontSize: "12px",
              }}
            >
              Save
            </button>
          </div>
        </div>
      )}

      {/* Explain Modal */}
      <Modal isOpen={isExplain} toggle={handleCloseExtraction} centered>
        <ModalHeader toggle={handleCloseExtraction}>
          {`Explanation of "${extraction?.query ?? selectedText}"`}
        </ModalHeader>
        <ModalBody>{isLoading ? "Loading..." : extraction?.llm_response}</ModalBody>
      </Modal>
    </div>
  );
};

export default PdfViewerWithPopup;
